<div class="container">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">
        <div class="panel">
          <?php $__env->startComponent('components.who'); ?>
          <?php if (isset($__componentOriginal647eb0f6470bbcabb710a928133507bfd00b970e)): ?>
<?php $component = $__componentOriginal647eb0f6470bbcabb710a928133507bfd00b970e; ?>
<?php unset($__componentOriginal647eb0f6470bbcabb710a928133507bfd00b970e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\laragon\www\Work\dietbite_weanio\resources\views/welcome.blade.php ENDPATH**/ ?>