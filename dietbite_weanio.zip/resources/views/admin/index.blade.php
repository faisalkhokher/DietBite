@extends('layouts.admin')
@section('content')  
<div class="page-wrapper">
					
    

    <div class="page-content">

<div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
  <div>
    <h4 class="mb-3 mb-md-0">Welcome to Dashboard</h4>
  </div>
</div>

    </div>


</div>
@endsection
